import { useEffect, useRef } from 'react';

const COLORS = ['#E2B05A', '#F3D08A', '#FFFFFF', '#D2553F', '#E2B05A'];

/**
 * Full-screen canvas layer: gentle snowfall, a sparkle trail that follows the
 * cursor (or finger), and star bursts on demand via `burstRef.current(x, y)`.
 * Honours prefers-reduced-motion by switching all motion off.
 */
export default function Sparkles({ burstRef }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let w = 0, h = 0;

    const resize = () => {
      const dpr = window.devicePixelRatio || 1;
      w = window.innerWidth;
      h = window.innerHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      canvas.style.width = w + 'px';
      canvas.style.height = h + 'px';
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener('resize', resize);

    const particles = [];
    const flakes = Array.from({ length: reduce ? 0 : 60 }, () => ({
      x: Math.random() * w,
      y: Math.random() * h,
      r: 1 + Math.random() * 2.2,
      speed: 0.25 + Math.random() * 0.5,
      phase: Math.random() * Math.PI * 2,
    }));

    const spawn = (x, y, count, spread, lift) => {
      for (let i = 0; i < count; i++) {
        const a = Math.random() * Math.PI * 2;
        const s = Math.random() * spread;
        particles.push({
          x, y,
          vx: Math.cos(a) * s,
          vy: Math.sin(a) * s - lift,
          life: 0,
          max: 550 + Math.random() * 550,
          size: 3 + Math.random() * (spread > 2 ? 8 : 5),
          rot: Math.random() * Math.PI,
          vr: (Math.random() - 0.5) * 0.15,
          color: COLORS[(Math.random() * COLORS.length) | 0],
          star: Math.random() < 0.65,
        });
      }
    };

    let lastMove = 0;
    const onMove = (e) => {
      if (reduce) return;
      const now = performance.now();
      if (now - lastMove < 14) return;
      lastMove = now;
      spawn(e.clientX, e.clientY, 2, 1.1, 0.2);
    };
    window.addEventListener('pointermove', onMove, { passive: true });

    if (burstRef) burstRef.current = (x, y) => { if (!reduce) spawn(x, y, 40, 5, 1.6); };

    const drawStar = (x, y, r, rot) => {
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(rot);
      ctx.beginPath();
      for (let i = 0; i < 8; i++) {
        const rr = i % 2 ? r * 0.3 : r;
        const a = (i * Math.PI) / 4;
        ctx.lineTo(Math.cos(a) * rr, Math.sin(a) * rr);
      }
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    };

    let prev = performance.now();
    let raf;
    const tick = (now) => {
      const dt = Math.min(50, now - prev);
      prev = now;
      const k = dt * 0.06; // ~1 at 60 fps
      ctx.clearRect(0, 0, w, h);

      ctx.fillStyle = 'rgba(255,255,255,0.8)';
      for (const f of flakes) {
        f.y += f.speed * k;
        f.phase += dt * 0.0012;
        f.x += Math.sin(f.phase) * 0.3;
        if (f.y > h + 5) { f.y = -5; f.x = Math.random() * w; }
        ctx.beginPath();
        ctx.arc(f.x, f.y, f.r, 0, Math.PI * 2);
        ctx.fill();
      }

      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.life += dt;
        if (p.life > p.max) { particles.splice(i, 1); continue; }
        p.vy += 0.06 * k;
        p.x += p.vx * k;
        p.y += p.vy * k;
        p.rot += p.vr * k;
        const t = 1 - p.life / p.max;
        ctx.globalAlpha = t;
        ctx.fillStyle = p.color;
        if (p.star) drawStar(p.x, p.y, p.size * (0.5 + 0.5 * t), p.rot);
        else { ctx.beginPath(); ctx.arc(p.x, p.y, p.size * 0.3, 0, Math.PI * 2); ctx.fill(); }
      }
      ctx.globalAlpha = 1;
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
      window.removeEventListener('pointermove', onMove);
    };
  }, [burstRef]);

  return <canvas ref={canvasRef} className="fx" aria-hidden="true" />;
}
