import { TREATS } from './treats.js';

const VB_W = 600;
const VB_H = 760;

const TREE =
  'M300 30 L395 175 Q380 183 362 180 L455 315 Q437 324 412 320 L515 465 Q494 477 462 472 L575 640 Q300 672 25 640 L138 472 Q106 477 85 465 L188 320 Q163 324 145 315 L238 180 Q220 183 205 175 Z';

const star5 = (cx, cy, r) => {
  let d = '';
  for (let i = 0; i < 10; i++) {
    const rr = i % 2 ? r * 0.45 : r;
    const a = -Math.PI / 2 + (i * Math.PI) / 5;
    d += (i ? 'L' : 'M') + (cx + Math.cos(a) * rr).toFixed(1) + ' ' + (cy + Math.sin(a) * rr).toFixed(1);
  }
  return d + 'Z';
};

const flake = (cx, cy, r) => {
  let d = '';
  for (let i = 0; i < 3; i++) {
    const a = (i * Math.PI) / 3;
    const dx = Math.cos(a) * r, dy = Math.sin(a) * r;
    d += `M${cx - dx} ${cy - dy}L${cx + dx} ${cy + dy}`;
  }
  return d;
};

const GOLD_STARS = [
  [300, 34, 30], [120, 120, 13], [470, 95, 10], [548, 262, 14], [62, 300, 9], [355, 205, 9],
  [190, 420, 10], [440, 430, 8], [520, 560, 11], [80, 520, 12], [230, 560, 9], [370, 555, 8],
  [575, 700, 9], [40, 690, 8],
];
const RED_FLAKES = [[505, 180, 14], [90, 210, 10], [468, 360, 12], [115, 410, 11], [258, 300, 9], [560, 430, 10], [345, 445, 9], [60, 600, 12]];
const DOTS = [[170, 70], [430, 160], [70, 380], [520, 330], [250, 410], [400, 600], [205, 640], [560, 520], [30, 450], [330, 700], [480, 690]];

/**
 * The tree: one SVG drawing plus 12 real <button>s positioned over it.
 * status(day) → 'opened' | 'today' | 'ready' | 'locked'
 */
export default function Tree({ status, onPick, shaking }) {
  return (
    <div className="tree" role="group" aria-label="Advent tree: 12 doors">
      <svg viewBox={`0 0 ${VB_W} ${VB_H}`} className="tree-art" aria-hidden="true">
        {DOTS.map(([x, y], i) => <circle key={'d' + i} cx={x} cy={y} r="3" fill="#FFFFFF" opacity="0.9" />)}
        <rect x="272" y="645" width="56" height="62" rx="4" fill="#8B6B4E" />
        <path d={TREE} fill="#4F6B50" />
        {RED_FLAKES.map(([x, y, r], i) => (
          <path key={'f' + i} d={flake(x, y, r)} stroke="#D2553F" strokeWidth="2.4" strokeLinecap="round" fill="none" />
        ))}
        {GOLD_STARS.map(([x, y, r], i) => <path key={'s' + i} d={star5(x, y, r)} fill="#E2B05A" />)}

        {/* candy cane */}
        <g transform="translate(36 560) rotate(-12)">
          <path d="M14 112 V26 a14 14 0 0 1 28 0 v6" fill="none" stroke="#FFFFFF" strokeWidth="9" strokeLinecap="round" />
          <path d="M9.5 40 l9 -6 M9.5 58 l9 -6 M9.5 76 l9 -6 M9.5 94 l9 -6 M18 18 l-7 -3 M30 12 l2 -8 M41 20 l8 -2" stroke="#D2553F" strokeWidth="4" strokeLinecap="round" />
        </g>

        {/* gingerbread */}
        <g transform="translate(500 640)">
          <path d="M40 4a14 14 0 1 0 .1 0 Z M27 30h26l20 8-5 12-15-5v14l10 30H49l-9-18-9 18H17l10-30V45l-15 5-5-12z" fill="#C9935C" />
          <path d="M34 15v.1 M46 15v.1 M35 22q5 4 10 0 M40 36v.1 M40 46v.1 M14 40l6 2 M66 40l-6 2" stroke="#FFFFFF" strokeWidth="3" strokeLinecap="round" fill="none" />
        </g>

        <text x="0" y="0" transform="translate(196 150) rotate(-56)" className="script">merry christmas</text>
        <text x="0" y="0" transform="translate(486 440) rotate(-57)" className="script">happy holidays</text>
      </svg>

      {TREATS.map((t) => {
        const s = status(t.day);
        const label =
          s === 'locked'
            ? `Day ${t.day}, opens ${t.day} December`
            : `Day ${t.day}, ${t.type}: ${t.title}${s === 'opened' ? ', opened' : s === 'today' ? ", today's treat" : ''}`;
        return (
          <button
            key={t.day}
            type="button"
            className={`num num--${s}${shaking === t.day ? ' num--shake' : ''}`}
            style={{ left: `${(t.x / VB_W) * 100}%`, top: `${(t.y / VB_H) * 100}%` }}
            aria-label={label}
            aria-disabled={s === 'locked' ? 'true' : undefined}
            onClick={(e) => onPick(t, e)}
          >
            {s === 'today' && <span className="halo" aria-hidden="true" />}
            <span className="num__text">{t.day}</span>
            {s === 'opened' && (
              <svg className="badge" viewBox="0 0 24 24" aria-hidden="true">
                <path d={star5(12, 12.5, 11)} fill="#E2B05A" />
              </svg>
            )}
          </button>
        );
      })}
    </div>
  );
}
