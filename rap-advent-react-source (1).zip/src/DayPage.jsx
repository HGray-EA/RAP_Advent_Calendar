import { useEffect, useMemo } from 'react';
import { Blocks } from './blocks/Blocks.jsx';
import { Quiz, PipelineGame, Checklist, ReviewGame, ParcelGame, makePledge } from './blocks/Interactive.jsx';
import { CONTENT } from './content.js';
import { TREATS, LEVELS } from './treats.js';

function TreatIcon({ treat, size = 84 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" aria-hidden="true">
      <path d={treat.icon[0]} fill="none" stroke="#4F6B50" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
      <path d={treat.icon[1]} fill="none" stroke="#D2553F" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export default function DayPage({ treat, lang, setLang, count, locked }) {
  const content = CONTENT[treat.day];
  const prev = TREATS.find((t) => t.day === treat.day - 1);
  const next = TREATS.find((t) => t.day === treat.day + 1);
  const interactive = useMemo(
    () => ({ quiz: Quiz, pipeline: PipelineGame, checklist: Checklist, review: ReviewGame, parcels: ParcelGame, pledge: makePledge(count) }),
    [count]
  );

  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = `Day ${treat.day}: ${treat.title} – RAP Advent`;
    return () => { document.title = 'RAP Advent Calendar'; };
  }, [treat]);

  return (
    <article className="day">
      <nav className="day__nav" aria-label="Calendar navigation">
        <a href="#" className="back">
          <svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true"><path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" /></svg>
          Back to the tree
        </a>
        <div className="lang" role="group" aria-label="Code language">
          <span className="lang__label">Code in</span>
          {[['r', 'R'], ['py', 'Python']].map(([id, label]) => (
            <button key={id} type="button" aria-pressed={lang === id} className={lang === id ? 'lang__btn lang__btn--on' : 'lang__btn'} onClick={() => setLang(id)}>
              {label}
            </button>
          ))}
        </div>
      </nav>

      <header className="day__head">
        <TreatIcon treat={treat} />
        <div>
          <p className="eyebrow">
            Day {treat.day} · {treat.type} · {LEVELS.find((l) => l.id === treat.level).label} level · {treat.mins} min
          </p>
          <h1 className="day__title">{treat.title}</h1>
          <p className="day__theme">Theme: <strong>{treat.theme}</strong></p>
        </div>
      </header>

      {locked ? (
        <section className="locked">
          <h2 className="page-h">No peeking!</h2>
          <p className="page-p">This treat opens on {treat.day} December. Come back then.</p>
        </section>
      ) : (
        <>
          <p className="day__intro">{content.intro}</p>
          <div className="day__body">
            <Blocks blocks={content.blocks} lang={lang} setLang={setLang} interactive={interactive} />
          </div>
        </>
      )}

      <nav className="pager" aria-label="Previous and next day">
        {prev ? (
          <a href={`#day-${prev.day}`} className="pager__link">
            <span className="pager__dir">← Day {prev.day}</span>
            <span className="pager__title">{prev.title}</span>
          </a>
        ) : <span />}
        {next ? (
          <a href={`#day-${next.day}`} className="pager__link pager__link--next">
            <span className="pager__dir">Day {next.day} →</span>
            <span className="pager__title">{next.title}</span>
          </a>
        ) : (
          <a href="#" className="pager__link pager__link--next">
            <span className="pager__dir">Back to the tree →</span>
            <span className="pager__title">See everything you’ve unwrapped</span>
          </a>
        )}
      </nav>
    </article>
  );
}
