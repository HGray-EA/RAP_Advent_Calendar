import { useMemo, useState } from 'react';
import { Rich } from './Blocks.jsx';

const pick = (lang, item) => (lang === 'py' ? item.py : item.r);

/* =========================================================
   Day 2 – Naughty or Nice?
   ========================================================= */
const QUIZ = [
  {
    nice: false, day: 7, principle: 'Portable, relative file paths',
    prompt: 'An elf starts every script like this…',
    r: 'setwd("C:/Users/elf/Desktop/presents_FINAL_v3")\ngifts <- read.csv("gifts.csv")',
    py: 'import os, pandas as pd\nos.chdir(r"C:\\Users\\elf\\Desktop\\presents_FINAL_v3")\ngifts = pd.read_csv("gifts.csv")',
    why: 'That folder only exists on one laptop – nobody else, and no server, can run it. Work inside a project and use relative paths (`here::here()` in R, `pathlib.Path` in Python). Better still, read straight from Unity Catalog.',
  },
  {
    nice: false, day: 7, principle: 'Keep secrets out of code',
    prompt: 'Connecting to DASH so the script “just works”…',
    r: 'Sys.setenv(DATABRICKS_TOKEN = "dapi8f3c1e0b7a…")\ncon <- DBI::dbConnect(odbc::databricks(),\n                      httpPath = "/sql/1.0/warehouses/abc123")',
    py: 'conn = sql.connect(\n    server_hostname="adb-123.azuredatabricks.net",\n    http_path="/sql/1.0/warehouses/abc123",\n    access_token="dapi8f3c1e0b7a…",\n)',
    why: 'A token in code ends up in Git history forever, where anyone with the repo can use it. Put it in `.Renviron` or `.env` (both git-ignored) and read it with `Sys.getenv()` / `os.getenv()`.',
  },
  {
    nice: true, day: 12, principle: 'Deterministic randomness',
    prompt: 'Before sampling which households to quality-check…',
    r: 'set.seed(2512)\nqa_sample <- dplyr::slice_sample(deliveries, n = 100)',
    py: 'qa_sample = deliveries.sample(n=100, random_state=2512)',
    why: 'Fixing the seed means the “random” sample is identical every run, so anyone re-running the pipeline checks the same households.',
  },
  {
    nice: false, day: 4, principle: 'Don’t repeat yourself – write functions',
    prompt: 'Cleaning the deliveries for each region…',
    r: 'north <- d |> filter(region == "North") |> mutate(name = str_to_title(name))\nsouth <- d |> filter(region == "South") |> mutate(name = str_to_title(name))\neast  <- d |> filter(region == "East")  |> mutate(name = str_to_title(name))\n# …and 9 more',
    py: 'north = d[d.region == "North"].assign(name=lambda x: x.name.str.title())\nsouth = d[d.region == "South"].assign(name=lambda x: x.name.str.title())\neast  = d[d.region == "East"].assign(name=lambda x: x.name.str.title())\n# …and 9 more',
    why: 'Copy-paste means a fix must be made 12 times – and one will be missed. Write `clean_region()` once and apply it to every region.',
  },
  {
    nice: true, day: 4, principle: 'Configuration, not hard-coding',
    prompt: 'Choosing which year and table to report on…',
    r: 'cfg <- config::get()\nsql <- glue::glue_sql(\n  "SELECT * FROM {DBI::SQL(cfg$source_table)} WHERE delivery_year = {cfg$year}",\n  .con = con)',
    py: 'cfg = yaml.safe_load(open("config.yaml"))\ncur.execute(\n    f"SELECT * FROM {cfg[\'source_table\']} WHERE delivery_year = :year",\n    {"year": cfg["year"]},\n)',
    why: 'Values that change between runs live in one config file, and the year is passed as a parameter rather than pasted into SQL. Next year you edit one line.',
  },
];

export function Quiz({ lang }) {
  const [i, setI] = useState(0);
  const [picked, setPicked] = useState(null);
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);
  const q = QUIZ[i];
  const correct = picked !== null && (picked === 'nice') === q.nice;

  const answer = (v) => {
    if (picked) return;
    setPicked(v);
    if ((v === 'nice') === q.nice) setScore((s) => s + 1);
  };
  const next = () => {
    if (i === QUIZ.length - 1) setDone(true);
    else { setI(i + 1); setPicked(null); }
  };
  const restart = () => { setI(0); setPicked(null); setScore(0); setDone(false); };

  if (done) {
    return (
      <section className="play play--done">
        <h3 className="play__big">{score >= 4 ? 'You’re on the Nice list!' : score >= 2 ? 'Mostly nice…' : 'Coal for now – there’s time!'}</h3>
        <p>You scored <strong>{score} / 5</strong>. Each answer points to the day that covers it in depth.</p>
        <button type="button" className="btn btn--ghost" onClick={restart}>Play again</button>
      </section>
    );
  }

  return (
    <section className="play" aria-label="Naughty or Nice quiz">
      <div className="play__progress">
        {QUIZ.map((_, k) => <span key={k} className={k < i ? 'dot dot--done' : k === i ? 'dot dot--now' : 'dot'} />)}
        <span className="play__count">Snippet {i + 1} of 5 · score {score}</span>
      </div>
      <p className="play__prompt">{q.prompt}</p>
      <pre className="code__pre code__pre--solo"><code>{pick(lang, q)}</code></pre>
      {picked === null ? (
        <div className="choice">
          <button type="button" className="choice__btn" onClick={() => answer('naughty')}>Naughty – lump of coal</button>
          <button type="button" className="choice__btn choice__btn--nice" onClick={() => answer('nice')}>Nice – a present!</button>
        </div>
      ) : (
        <>
          <div className={correct ? 'feedback feedback--ok' : 'feedback feedback--no'} role="status">
            <strong>{correct ? 'Correct! ' : 'Not quite. '}{q.nice ? 'This one’s on the Nice list.' : 'This one gets coal.'}</strong>
            <p><Rich text={q.why} /></p>
            <p className="feedback__meta">Principle: <strong>{q.principle}</strong> · <a href={`#day-${q.day}`}>more on Day {q.day}</a></p>
          </div>
          <button type="button" className="btn btn--primary play__next" onClick={next}>{i === QUIZ.length - 1 ? 'See my score' : 'Next snippet →'}</button>
        </>
      )}
    </section>
  );
}

/* =========================================================
   Day 5 – Untangle the pipeline
   ========================================================= */
const STAGES = [
  { id: 'read', label: 'Read from Unity Catalog', fn: 'read_deliveries()' },
  { id: 'validate', label: 'Validate inputs', fn: 'validate_deliveries()' },
  { id: 'clean', label: 'Clean & tidy', fn: 'clean_deliveries()' },
  { id: 'agg', label: 'Aggregate by region', fn: 'summarise_region()' },
  { id: 'viz', label: 'Make charts & tables', fn: 'make_charts()' },
  { id: 'render', label: 'Render Quarto report', fn: 'render_report()' },
];
const DECOYS = [
  { id: 'excel', label: 'Hand-edit totals in Excel', why: 'Manual edits can’t be re-run or reviewed. Fix the problem upstream in code.' },
  { id: 'email', label: 'Email final_v2.xlsx to yourself', why: 'Email isn’t version control. Commit code to Git; outputs are rebuilt by the pipeline.' },
];
const ORDER = ['agg', 'excel', 'clean', 'render', 'read', 'email', 'viz', 'validate'];

export function PipelineGame() {
  const [placed, setPlaced] = useState([]);
  const [binned, setBinned] = useState([]);
  const [coal, setCoal] = useState(0);
  const [msg, setMsg] = useState({ text: 'Start with the stage that doesn’t need anything from another stage.', bad: false });
  const all = [...STAGES, ...DECOYS];
  const won = placed.length === STAGES.length;

  const choose = (id) => {
    const decoy = DECOYS.find((d) => d.id === id);
    if (decoy) {
      setCoal((c) => c + 1); setBinned((b) => [...b, id]);
      return setMsg({ text: 'Lump of coal! ' + decoy.why, bad: true });
    }
    const expected = STAGES[placed.length].id;
    if (id === expected) {
      const n = placed.length + 1;
      setPlaced((p) => [...p, id]);
      return setMsg({ text: n === STAGES.length ? 'Sleigh loaded!' : `Nice – ${STAGES[n - 1].fn} runs. What needs its output next?`, bad: false });
    }
    setCoal((c) => c + 1);
    const s = STAGES.find((x) => x.id === id);
    setMsg({ text: `Not yet – “${s.label}” needs an input that hasn’t been made. What does it depend on?`, bad: true });
  };
  const restart = () => { setPlaced([]); setBinned([]); setCoal(0); setMsg({ text: 'Start with the stage that doesn’t need anything from another stage.', bad: false }); };

  return (
    <section className="play" aria-label="Untangle the pipeline game">
      <div className="play__stats"><span>Stages loaded: <strong>{placed.length} / 6</strong></span><span>Lumps of coal: <strong>{coal}</strong></span></div>
      <ol className="slots">
        {STAGES.map((s, k) => (
          <li key={s.id} className={k < placed.length ? 'slot slot--on' : 'slot'}>
            <span className="slot__n">{k + 1}</span>
            <span className="slot__label">{k < placed.length ? s.label : '…'}</span>
            <code className="slot__fn">{k < placed.length ? s.fn : ''}</code>
          </li>
        ))}
      </ol>
      <p className={msg.bad ? 'feedback feedback--no' : 'feedback feedback--ok'} role="status">{msg.text}</p>
      {won ? (
        <div className="play--done">
          <h3 className="play__big">Pipeline built! {coal === 0 ? 'Zero coal.' : `${coal} lump${coal === 1 ? '' : 's'} of coal.`}</h3>
          <button type="button" className="btn btn--ghost" onClick={restart}>Shuffle &amp; replay</button>
        </div>
      ) : (
        <div className="parcels">
          {ORDER.filter((id) => !placed.includes(id) && !binned.includes(id)).map((id) => {
            const p = all.find((x) => x.id === id);
            return (
              <button key={id} type="button" className="parcel" onClick={() => choose(id)}>
                <svg width="30" height="30" viewBox="0 0 48 48" aria-hidden="true"><path d="M10 22h28v18H10z M8 16h32v6H8z M24 16v24" fill="none" stroke="#4F6B50" strokeWidth="2.2" /><path d="M24 16c-3-6-10-7-9-2s9 2 9 2c3-6 10-7 9-2s-9 2-9 2" fill="none" stroke="#D2553F" strokeWidth="2.4" /></svg>
                {p.label}
              </button>
            );
          })}
        </div>
      )}
    </section>
  );
}

/* =========================================================
   Day 6 – RAP readiness checker
   ========================================================= */
const LEVELS = [
  { key: 'Baseline', items: [
    ['b1', 'Outputs are produced by code in an open-source language', 'R or Python, not point-and-click', 1],
    ['b2', 'Code is under version control', 'A Git repository', 3],
    ['b3', 'Repository has a README', 'What it does, how to run it, who owns it', 3],
    ['b4', 'Code has been peer reviewed', 'Another analyst has read and run it', 8],
    ['b5', 'Code is published openly where possible', 'Or shared internally if sensitive', 1] ] },
  { key: 'Silver', items: [
    ['s1', 'Runs end-to-end with minimal manual steps', 'One command reproduces every output', 5],
    ['s2', 'Logic is wrapped in reusable functions', 'No copy-pasted blocks', 4],
    ['s3', 'Dependencies are recorded', 'renv.lock or uv.lock', 7],
    ['s4', 'Follows an agreed style guide', 'Checked by lintr / ruff', 8],
    ['s5', 'Has unit tests', 'testthat or pytest', 9],
    ['s6', 'Inputs are validated automatically', 'pointblank, pandera or table constraints', 10],
    ['s7', 'Settings live in a config file', 'No hard-coded years, tables or paths', 4] ] },
  { key: 'Gold', items: [
    ['g1', 'Code is packaged', 'An installable R / Python package', 11],
    ['g2', 'Tests run automatically on every change', 'GitHub Actions or Azure DevOps', 11],
    ['g3', 'Runs on a schedule or trigger', 'Posit Connect schedule or Lakeflow Jobs', 11],
    ['g4', 'Changes are versioned and signposted', 'Changelog and tagged releases', 3] ] },
];

export function Checklist() {
  const [on, setOn] = useState({});
  const [project, setProject] = useState('');
  const [copied, setCopied] = useState(false);
  const stats = LEVELS.map((l) => ({ key: l.key, done: l.items.filter((it) => on[it[0]]).length, total: l.items.length }));
  const full = stats.map((s) => s.done === s.total);
  const level = full[0] && full[1] && full[2] ? 'Gold' : full[0] && full[1] ? 'Silver' : full[0] ? 'Baseline' : 'Getting started';
  const next = LEVELS.flatMap((l) => l.items).find((it) => !on[it[0]]);

  const markdown = useMemo(() => {
    const lines = [`## RAP readiness: ${project || 'my project'}`, '', `Level: **${level}**`, ''];
    LEVELS.forEach((l) => {
      lines.push(`### ${l.key}`);
      l.items.forEach(([id, label]) => lines.push(`- [${on[id] ? 'x' : ' '}] ${label}`));
      lines.push('');
    });
    return lines.join('\n');
  }, [on, project, level]);

  const copy = async () => {
    try { await navigator.clipboard.writeText(markdown); setCopied(true); setTimeout(() => setCopied(false), 1600); } catch { /* blocked */ }
  };

  return (
    <section className="tool" aria-label="RAP readiness checker">
      <div className="tool__main">
        <label className="field">
          Project name
          <input type="text" value={project} onChange={(e) => setProject(e.target.value)} placeholder="e.g. Farm business survey pipeline" />
        </label>
        {LEVELS.map((l, k) => (
          <fieldset key={l.key} className="level">
            <legend><span className="level__name">{l.key}</span> <span className="level__count">{stats[k].done} of {stats[k].total}</span></legend>
            {l.items.map(([id, label, how, day]) => (
              <div key={id} className="check">
                <input type="checkbox" id={id} checked={!!on[id]} onChange={() => setOn((o) => ({ ...o, [id]: !o[id] }))} />
                <label htmlFor={id}><strong>{label}</strong><span>{how}</span></label>
                <a href={`#day-${day}`} className="check__day">Day {day}</a>
              </div>
            ))}
          </fieldset>
        ))}
      </div>
      <aside className="tool__side">
        <div className="result">
          <span className="eyebrow">Your RAP level</span>
          <span className="result__level">{level}</span>
          {stats.map((s) => (
            <div key={s.key} className="bar">
              <div className="bar__label"><span>{s.key}</span><span>{s.done} / {s.total}</span></div>
              <div className="bar__track" aria-hidden="true"><div className="bar__fill" style={{ width: `${(100 * s.done) / s.total}%` }} /></div>
            </div>
          ))}
        </div>
        <div className="next-step">
          <span className="eyebrow">Your next best step</span>
          <strong>{next ? next[1] : 'You’re Gold – share how you did it!'}</strong>
          {next && <a href={`#day-${next[3]}`}>See Day {next[3]} →</a>}
        </div>
        <button type="button" className="btn btn--primary" onClick={copy}>{copied ? 'Copied!' : 'Copy as Markdown checklist'}</button>
        <p className="muted small">Paste it into a GitHub issue, a pull request or your QA log. Nothing you tick leaves this page.</p>
      </aside>
    </section>
  );
}

/* =========================================================
   Day 8 – Code review elf
   ========================================================= */
const REVIEW = {
  r: [
    ['library(dplyr)'],
    ['setwd("C:/Users/elf/Desktop/sleigh")', 'Hard-coded path: only works on one laptop. Use an RStudio project and relative paths.'],
    ['con <- DBI::dbConnect(odbc::databricks(), httpPath = Sys.getenv("DATABRICKS_HTTP_PATH"))'],
    ['d <- DBI::dbGetQuery(con, "SELECT * FROM dash_catalog.santa.deliveries")'],
    ['d <- d[d$yr == 2026, ]', 'Hard-coded year: move it to config.yml (Day 4) and filter in the SQL query.'],
    ['d2 <- d'],
    ['d2$x <- d2$g * 1.2', 'Unclear names and a magic number. What is x? Why 1.2? Use descriptive names and a named, documented constant.'],
    ['write.csv(d2, "final_FINAL.csv")', 'Output name and location aren’t reproducible. Write to outputs/ with a name the pipeline controls.'],
    ['# TODO check numbers with Sarah', 'A manual QA step that lives in someone’s head. Turn it into an automated check or test (Days 9–10).'],
    ['print(sum(d2$x))'],
  ],
  py: [
    ['import pandas as pd'],
    ['os.chdir(r"C:\\Users\\elf\\Desktop\\sleigh")', 'Hard-coded path: only works on one laptop. Use relative paths from the project root.'],
    ['conn = sql.connect(server_hostname=os.getenv("DATABRICKS_SERVER_HOSTNAME"), ...)'],
    ['d = pd.read_sql("SELECT * FROM dash_catalog.santa.deliveries", conn)'],
    ['d = d[d.yr == 2026]', 'Hard-coded year: move it to config.yaml (Day 4) and filter in the SQL query.'],
    ['d2 = d'],
    ['d2["x"] = d2["g"] * 1.2', 'Unclear names and a magic number. What is x? Why 1.2? Use descriptive names and a named constant.'],
    ['d2.to_csv("final_FINAL.csv")', 'Output name and location aren’t reproducible. Write to outputs/ with a name the pipeline controls.'],
    ['# TODO check numbers with Sarah', 'A manual QA step that lives in someone’s head. Turn it into an automated check or test (Days 9–10).'],
    ['print(d2["x"].sum())'],
  ],
};

export function ReviewGame({ lang }) {
  const lines = REVIEW[lang === 'py' ? 'py' : 'r'];
  const [flags, setFlags] = useState({});
  const [checked, setChecked] = useState(false);
  const issues = lines.filter((l) => l[1]).length;
  const found = lines.filter((l, i) => l[1] && flags[i]).length;
  const wrong = lines.filter((l, i) => !l[1] && flags[i]).length;

  return (
    <section className="play" aria-label="Code review game">
      <p className="play__prompt">Click the lines you’d comment on in review. There are {issues} issues.</p>
      <ol className="review">
        {lines.map(([code, why], i) => {
          const state = checked ? (why && flags[i] ? 'hit' : why ? 'miss' : flags[i] ? 'false' : '') : flags[i] ? 'flag' : '';
          return (
            <li key={i}>
              <button
                type="button"
                aria-pressed={!!flags[i]}
                className={`review__line review__line--${state || 'plain'}`}
                onClick={() => !checked && setFlags((f) => ({ ...f, [i]: !f[i] }))}
              >
                <span className="review__n">{i + 1}</span>
                <code>{code}</code>
              </button>
              {checked && why && <p className="review__why"><Rich text={why} /></p>}
            </li>
          );
        })}
      </ol>
      {checked ? (
        <div className="feedback feedback--ok" role="status">
          <strong>You spotted {found} of {issues}{wrong ? `, plus ${wrong} line${wrong === 1 ? '' : 's'} that ${wrong === 1 ? 'was' : 'were'} fine` : ''}.</strong>
          <p>Missed ones are outlined in red, with the comment a reviewer would leave.</p>
          <button type="button" className="btn btn--ghost" onClick={() => { setFlags({}); setChecked(false); }}>Try again</button>
        </div>
      ) : (
        <button type="button" className="btn btn--primary" onClick={() => setChecked(true)}>Submit my review</button>
      )}
    </section>
  );
}

/* =========================================================
   Day 10 – Catch the bad parcels
   ========================================================= */
const ROWS = [
  { id: 'C-1041', region: 'North', gifts: 3, bad: null },
  { id: 'C-1042', region: '', gifts: 2, bad: 'Missing region – fails a not-null check.' },
  { id: 'C-1043', region: 'South', gifts: -3, bad: 'Negative gifts – fails a range check (0–10).' },
  { id: 'C-1044', region: 'East', gifts: 4, bad: null },
  { id: 'C-1041', region: 'West', gifts: 1, bad: 'Duplicate child_id – fails a uniqueness check.' },
  { id: 'C-1046', region: 'Narnia', gifts: 2, bad: 'Unknown region – fails an allowed-values check.' },
  { id: 'C-1047', region: 'West', gifts: 5, bad: null },
  { id: 'C-1048', region: 'South', gifts: 99, bad: 'Implausible value – fails a range check (0–10).' },
];

export function ParcelGame() {
  const [flags, setFlags] = useState({});
  const [checked, setChecked] = useState(false);
  const total = ROWS.filter((r) => r.bad).length;
  const caught = ROWS.filter((r, i) => r.bad && flags[i]).length;
  const wrong = ROWS.filter((r, i) => !r.bad && flags[i]).length;

  return (
    <section className="play" aria-label="Catch the bad parcels game">
      <p className="play__prompt">A fresh batch has landed in <code className="inline-code">dash_catalog.santa.deliveries</code>. Flag every row that should stop the pipeline.</p>
      <div className="table-wrap">
        <table className="rows">
          <thead><tr><th scope="col">Flag</th><th scope="col">child_id</th><th scope="col">region</th><th scope="col">gifts</th>{checked && <th scope="col">Why</th>}</tr></thead>
          <tbody>
            {ROWS.map((r, i) => {
              const cls = checked ? (r.bad && flags[i] ? 'row--hit' : r.bad ? 'row--miss' : flags[i] ? 'row--false' : '') : flags[i] ? 'row--flag' : '';
              return (
                <tr key={i} className={cls}>
                  <td>
                    <input type="checkbox" aria-label={`Flag row ${i + 1}`} checked={!!flags[i]} disabled={checked} onChange={() => setFlags((f) => ({ ...f, [i]: !f[i] }))} />
                  </td>
                  <td><code>{r.id}</code></td>
                  <td>{r.region || <em className="muted">(blank)</em>}</td>
                  <td>{r.gifts}</td>
                  {checked && <td className="small">{r.bad || 'Fine'}</td>}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      {checked ? (
        <div className="feedback feedback--ok" role="status">
          <strong>You caught {caught} of {total} bad parcels{wrong ? ` and stopped ${wrong} good one${wrong === 1 ? '' : 's'}` : ''}.</strong>
          <p>Every one of these can be caught automatically – see the code below.</p>
          <button type="button" className="btn btn--ghost" onClick={() => { setFlags({}); setChecked(false); }}>Try again</button>
        </div>
      ) : (
        <button type="button" className="btn btn--primary" onClick={() => setChecked(true)}>Run my checks</button>
      )}
    </section>
  );
}

/* =========================================================
   Day 12 – Badge & pledge
   ========================================================= */
const PLEDGE_KEY = 'rap-advent-pledge';

export function makePledge(count) {
  return function Pledge() {
    const [text, setText] = useState(() => { try { return localStorage.getItem(PLEDGE_KEY) || ''; } catch { return ''; } });
    const [made, setMade] = useState(!!text);
    const [copied, setCopied] = useState(false);
    const badge = count >= 12 ? 'Gold' : count >= 8 ? 'Silver' : count >= 4 ? 'Baseline' : 'Elf-in-training';

    const submit = (e) => {
      e.preventDefault();
      if (!text.trim()) return;
      try { localStorage.setItem(PLEDGE_KEY, text.trim()); } catch { /* storage unavailable */ }
      setMade(true);
    };
    const copy = async () => {
      try {
        await navigator.clipboard.writeText(`My RAP pledge for the new year: ${text.trim()} #RAPAdvent`);
        setCopied(true); setTimeout(() => setCopied(false), 1600);
      } catch { /* blocked */ }
    };

    return (
      <section className="pledge" aria-label="Your badge and pledge">
        <div className="badge-card">
          <svg width="96" height="96" viewBox="0 0 48 48" aria-hidden="true">
            <path d="M24 4l5.5 11.5 12.5 1.5-9.3 8.6 2.4 12.4L24 31.8 12.9 38l2.4-12.4L6 17l12.5-1.5z" fill="#F3D08A" stroke="#B5402D" strokeWidth="1.6" strokeLinejoin="round" />
          </svg>
          <div>
            <span className="eyebrow">Your badge</span>
            <p className="badge-card__level">{badge}</p>
            <p className="muted">{count} of 12 treats unwrapped</p>
          </div>
        </div>
        {made ? (
          <div className="pledge__made">
            <span className="eyebrow">My RAP pledge for the new year</span>
            <p className="pledge__text">“{text.trim()}”</p>
            <div className="row-gap">
              <button type="button" className="btn btn--primary" onClick={copy}>{copied ? 'Copied!' : 'Copy to share with your team'}</button>
              <button type="button" className="btn btn--ghost" onClick={() => setMade(false)}>Edit</button>
            </div>
          </div>
        ) : (
          <form onSubmit={submit} className="pledge__form">
            <label className="field">
              One RAP habit I’ll adopt in January
              <textarea rows={3} value={text} onChange={(e) => setText(e.target.value)} placeholder="e.g. Add a lockfile and a README to our survey pipeline" />
            </label>
            <button type="submit" className="btn btn--primary">Make my pledge</button>
          </form>
        )}
      </section>
    );
  };
}
