import { Fragment, useState } from 'react';

/* ---------- inline formatting: `code` and **bold** ---------- */
export function Rich({ text }) {
  const parts = text.split(/(`[^`]+`|\*\*[^*]+\*\*)/g);
  return parts.map((p, i) => {
    if (p.startsWith('`') && p.endsWith('`')) return <code key={i} className="inline-code">{p.slice(1, -1)}</code>;
    if (p.startsWith('**') && p.endsWith('**')) return <strong key={i}>{p.slice(2, -2)}</strong>;
    return <Fragment key={i}>{p}</Fragment>;
  });
}

/* ---------- code block with R / Python (or other) tabs ---------- */
const LANG_LABEL = { r: 'R', py: 'Python', sql: 'SQL', bash: 'Terminal', yaml: 'YAML', md: 'Markdown', text: 'Text' };

function CodeLines({ code }) {
  return code.split('\n').map((line, i) => {
    const t = line.trimStart();
    const isComment = t.startsWith('#') || t.startsWith('--') || t.startsWith('//');
    return (
      <span key={i} className={isComment ? 'tok-comment' : undefined}>
        {line}
        {'\n'}
      </span>
    );
  });
}

export function Code({ title, tabs, lang, setLang }) {
  const preferred = tabs.findIndex((t) => t.lang === lang);
  const [local, setLocal] = useState(null);
  const idx = local ?? (preferred >= 0 ? preferred : 0);
  const active = tabs[Math.min(idx, tabs.length - 1)];
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(active.code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      setCopied(false);
    }
  };

  return (
    <figure className="code">
      <div className="code__bar">
        {title && <span className="code__title">{title}</span>}
        <div className="code__tabs" role="tablist" aria-label="Code language">
          {tabs.length > 1 &&
            tabs.map((t, i) => (
              <button
                key={t.label || t.lang}
                type="button"
                role="tab"
                aria-selected={t === active}
                className={t === active ? 'code__tab code__tab--on' : 'code__tab'}
                onClick={() => {
                  if ((t.lang === 'r' || t.lang === 'py') && setLang) { setLang(t.lang); setLocal(null); }
                  else setLocal(i);
                }}
              >
                {t.label || LANG_LABEL[t.lang]}
              </button>
            ))}
          {tabs.length === 1 && <span className="code__lang">{active.label || LANG_LABEL[active.lang]}</span>}
        </div>
        <button type="button" className="code__copy" onClick={copy}>{copied ? 'Copied!' : 'Copy'}</button>
      </div>
      <pre className="code__pre" tabIndex={0}><code><CodeLines code={active.code} /></code></pre>
    </figure>
  );
}

/* ---------- data-flow diagram ---------- */
const KIND = {
  data: { label: 'Data', cls: 'node--data' },
  code: { label: 'Code', cls: 'node--code' },
  check: { label: 'Check', cls: 'node--check' },
  out: { label: 'Output', cls: 'node--out' },
  manual: { label: 'Manual', cls: 'node--manual' },
  platform: { label: 'Platform', cls: 'node--platform' },
};

export function Flow({ title, nodes, note }) {
  return (
    <figure className="flow" aria-label={title}>
      {title && <figcaption className="flow__title">{title}</figcaption>}
      <ol className="flow__row">
        {nodes.map((n, i) => (
          <li key={i} className="flow__item">
            <div className={`node ${KIND[n.k]?.cls || ''}`}>
              {n.tag && <span className="node__tag">{n.tag}</span>}
              <span className="node__title">{n.t.replace(/_/g, '_\u200b')}</span>
              {n.s && <span className="node__sub">{n.s}</span>}
            </div>
            {i < nodes.length - 1 && (
              <svg className="flow__arrow" viewBox="0 0 32 16" aria-hidden="true">
                <path d="M2 8h24M20 3l6 5-6 5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            )}
          </li>
        ))}
      </ol>
      {note && <p className="flow__note"><Rich text={note} /></p>}
    </figure>
  );
}

/* ---------- small blocks ---------- */
export function Callout({ tone = 'tip', title, text }) {
  const icon = {
    tip: 'M12 3a6 6 0 0 1 4 10.5V16H8v-2.5A6 6 0 0 1 12 3z M9 19h6 M10 22h4',
    warn: 'M12 3l10 18H2z M12 10v5 M12 18v.1',
    defra: 'M12 3c4 3 6 6 6 10a6 6 0 0 1-12 0c0-4 2-7 6-10z M12 21V11',
  }[tone];
  return (
    <aside className={`callout callout--${tone}`}>
      <svg width="22" height="22" viewBox="0 0 24 24" aria-hidden="true"><path d={icon} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>
      <div>
        {title && <strong className="callout__title">{title}</strong>}
        <p><Rich text={text} /></p>
      </div>
    </aside>
  );
}

export function Links({ items }) {
  return (
    <section className="links" aria-label="Further reading">
      <h3>Further reading</h3>
      <ul>
        {items.map((l) => (
          <li key={l.url}>
            <a href={l.url} target="_blank" rel="noreferrer">{l.label}</a>
            {l.note && <span> – {l.note}</span>}
          </li>
        ))}
      </ul>
    </section>
  );
}

export function Reveal({ label, children }) {
  return (
    <details className="reveal">
      <summary>{label}</summary>
      <div className="reveal__body">{children}</div>
    </details>
  );
}

/* ---------- renderer ---------- */
export function Blocks({ blocks, lang, setLang, interactive }) {
  return blocks.map((b, i) => {
    switch (b.kind) {
      case 'h': return <h2 key={i} className="page-h">{b.text}</h2>;
      case 'p': return <p key={i} className="page-p"><Rich text={b.text} /></p>;
      case 'list': {
        const Tag = b.ordered ? 'ol' : 'ul';
        return <Tag key={i} className="page-list">{b.items.map((t) => <li key={t}><Rich text={t} /></li>)}</Tag>;
      }
      case 'code': return <Code key={i} title={b.title} tabs={b.tabs} lang={lang} setLang={setLang} />;
      case 'flow': return <Flow key={i} title={b.title} nodes={b.nodes} note={b.note} />;
      case 'callout': return <Callout key={i} tone={b.tone} title={b.title} text={b.text} />;
      case 'links': return <Links key={i} items={b.items} />;
      case 'reveal':
        return (
          <Reveal key={i} label={b.label}>
            <Blocks blocks={b.blocks} lang={lang} setLang={setLang} interactive={interactive} />
          </Reveal>
        );
      case 'interactive': {
        const C = interactive[b.name];
        return C ? <C key={i} lang={lang} /> : null;
      }
      default: return null;
    }
  });
}
