// Page content for each of the 12 days. Blocks are rendered by src/blocks/Blocks.jsx.
// Table names such as dash_catalog.santa.deliveries are made-up examples.

const L = {
  rapAF: { label: 'Reproducible Analytical Pipelines – Government Analysis Function', url: 'https://analysisfunction.civilservice.gov.uk/support/reproducible-analytical-pipelines/' },
  rapMVP: { label: 'RAP minimum standard (MVP)', url: 'https://github.com/best-practice-and-impact/rap_mvp_maturity_guidance/blob/master/Reproducible-Analytical-Pipelines-MVP.md' },
  qa: { label: 'Quality assurance of code for analysis and research', url: 'https://best-practice-and-impact.github.io/qa-of-code-guidance/intro.html' },
  infra: { label: 'Infrastructure for RAP – Analysis Function', url: 'https://analysisfunction.civilservice.gov.uk/support/reproducible-analytical-pipelines/infrastructure-for-rap' },
  dash: { label: 'Introducing Defra’s Data Analytics and Science Hub (DASH)', url: 'https://defradigital.blog.gov.uk/2022/09/29/data-tools-and-people-introducing-the-three-enablers-of-defras-data-analytics-and-science-hub/' },
  cookie: { label: 'govcookiecutter – project template', url: 'https://github.com/best-practice-and-impact/govcookiecutter' },
  nhsLevels: { label: 'Levels of RAP – NHS England RAP playbook', url: 'https://nhsengland.github.io/Health-RAP-Playbook-Alpha/Levels_of_RAP' },
  odbc: { label: 'odbc::databricks() reference', url: 'https://odbc.r-dbi.org/reference/databricks.html' },
  positDbx: { label: 'Connecting R to Databricks – Posit Solutions', url: 'https://solutions.posit.co/connections/db/databases/databricks/' },
  pyConn: { label: 'Databricks SQL Connector for Python', url: 'https://learn.microsoft.com/en-us/azure/databricks/dev-tools/python-sql-connector' },
  jobs: { label: 'Lakeflow Jobs (Azure Databricks)', url: 'https://learn.microsoft.com/en-us/azure/databricks/jobs/' },
  constraints: { label: 'Constraints on Azure Databricks', url: 'https://learn.microsoft.com/en-us/azure/databricks/tables/constraints' },
  connectSched: { label: 'Scheduling content on Posit Connect', url: 'https://docs.posit.co/connect/user/scheduling/' },
  connect: { label: 'Posit Connect user guide', url: 'https://docs.posit.co/connect/user/' },
  renv: { label: 'renv', url: 'https://rstudio.github.io/renv/' },
  uv: { label: 'uv', url: 'https://docs.astral.sh/uv/' },
  targets: { label: 'The {targets} R package user manual', url: 'https://books.ropensci.org/targets/' },
  testthat: { label: 'testthat', url: 'https://testthat.r-lib.org/' },
  pytest: { label: 'pytest', url: 'https://docs.pytest.org/' },
  tidyStyle: { label: 'The tidyverse style guide', url: 'https://style.tidyverse.org/' },
  pep8: { label: 'PEP 8 – Python style guide', url: 'https://peps.python.org/pep-0008/' },
  lintr: { label: 'lintr', url: 'https://lintr.r-lib.org/' },
  ruff: { label: 'Ruff', url: 'https://docs.astral.sh/ruff/' },
  pointblank: { label: 'pointblank', url: 'https://rstudio.github.io/pointblank/' },
  pandera: { label: 'pandera', url: 'https://pandera.readthedocs.io/' },
  rlibActions: { label: 'r-lib/actions – GitHub Actions for R', url: 'https://github.com/r-lib/actions' },
  ghActions: { label: 'GitHub Actions documentation', url: 'https://docs.github.com/en/actions' },
};

export const CONTENT = {
  1: {
    intro: 'A Reproducible Analytical Pipeline (RAP) is analysis written as code, so anyone can re-run it and get the same answer. Today: what that means, and what it looks like on Defra’s tech stack.',
    blocks: [
      { kind: 'h', text: 'What makes it a RAP?' },
      { kind: 'p', text: 'The Government Analysis Function describes RAPs as automated analytical processes that borrow software-engineering practice so they are **reproducible, auditable, efficient and high quality**. In practice that means:' },
      { kind: 'list', items: [
        'Every step from raw data to published output is **code**, in an open-source language such as R or Python',
        'The code lives in **version control** (Git), with a full history of every change',
        'Someone else has **peer reviewed** it',
        'It’s **documented** well enough for a colleague to run it without you',
      ] },
      { kind: 'h', text: 'Before and after' },
      { kind: 'flow', title: 'Christmas Eve, the old way', nodes: [
        { t: 'Download extract', s: 'CSV from a shared drive', k: 'manual' },
        { t: 'Fix it in Excel', s: 'hand-edited cells', k: 'manual' },
        { t: 'Paste into Word', s: 'tables copied by hand', k: 'manual' },
        { t: 'Email “final_v3”', s: 'no audit trail', k: 'manual' },
      ] },
      { kind: 'flow', title: 'The RAP way on Defra’s stack', nodes: [
        { t: 'Unity Catalog table', s: 'governed data', tag: 'DASH · Databricks', k: 'data' },
        { t: 'R or Python pipeline', s: 'functions, config', tag: 'Git', k: 'code' },
        { t: 'Tests & checks', s: 'run automatically', k: 'check' },
        { t: 'Quarto report', s: 'rendered from code', k: 'out' },
        { t: 'Published', s: 'scheduled refresh', tag: 'Posit Connect', k: 'platform' },
      ], note: 'Every arrow is code, so the whole chain can be re-run with one command.' },
      { kind: 'callout', tone: 'defra', title: 'Defra’s tech stack in one paragraph', text: 'Data lives in **DASH**, Defra’s Data Analytics & Science Hub, which is built on **Databricks** with **Unity Catalog** for governed access. Analysis is written in **R or Python** and kept in **Git**. Reports, apps and dashboards are published on **Posit Connect**. The next 11 days show how each piece fits together.' },
      { kind: 'h', text: 'Why bother?' },
      { kind: 'list', items: [
        'Next year’s figures are one command, not a week of copy-and-paste',
        'Mistakes are fixed once and stay fixed',
        'Anyone can see exactly how a number was produced',
        'The work survives people moving on',
      ] },
      { kind: 'links', items: [L.rapAF, L.rapMVP, L.qa, L.dash] },
    ],
  },

  2: {
    intro: 'Santa’s checking your scripts. Five snippets – decide whether each one helps or hurts reproducibility. Use the R / Python switch at the top to change language.',
    blocks: [
      { kind: 'interactive', name: 'quiz' },
      { kind: 'callout', tone: 'tip', title: 'The pattern behind every answer', text: 'Ask: **would this still work, and give the same answer, if a colleague ran it on a different machine next year?** If not, it’s on the naughty list.' },
      { kind: 'links', items: [L.qa, L.rapMVP] },
    ],
  },

  3: {
    intro: 'It’s the night before publication and a number looks wrong. Nobody knows which of six “final” spreadsheets it came from. Three ghosts arrive to show you version control.',
    blocks: [
      { kind: 'h', text: 'The Ghost of Code Past – history' },
      { kind: 'p', text: 'Every commit is a snapshot with a note attached. When a figure changes you can see exactly which line changed, when, and why.' },
      { kind: 'h', text: 'The Ghost of Code Present – small, clear commits' },
      { kind: 'p', text: '“Fix” tells a reviewer nothing. “Exclude test households from regional totals” tells them what to check.' },
      { kind: 'h', text: 'The Ghost of Code Yet to Come – branches and pull requests' },
      { kind: 'p', text: 'Branches let you try a new method without breaking the published pipeline. A pull request is where a colleague reviews it – your peer review and your audit trail in one place.' },
      { kind: 'flow', title: 'The everyday Git workflow', nodes: [
        { t: 'Create a branch', s: 'git switch -c', k: 'code' },
        { t: 'Commit small changes', s: 'clear messages', k: 'code' },
        { t: 'Open a pull request', s: 'on GitHub / Azure DevOps', k: 'platform' },
        { t: 'Peer review', s: 'comments & fixes', k: 'check' },
        { t: 'Merge to main', s: 'the trusted version', k: 'out' },
      ] },
      { kind: 'code', title: 'Commands you’ll use every day', tabs: [{ lang: 'bash', code:
`# start a new piece of work on its own branch
git switch -c fix-regional-totals

# see what changed, then commit with a useful message
git status
git diff
git add R/summarise_region.R
git commit -m "Exclude test households from regional totals"

# share it and open a pull request for review
git push -u origin fix-regional-totals

# Ghost of Code Past: who changed this, and why?
git log --oneline -- R/summarise_region.R` }] },
      { kind: 'callout', tone: 'warn', title: 'Never commit data or secrets', text: 'On DASH your data stays in Unity Catalog – Git holds only code. Add a `.gitignore` on day one so tokens and extracts can’t slip in by accident.' },
      { kind: 'code', title: '.gitignore', tabs: [{ lang: 'text', label: '.gitignore', code:
`# secrets – never commit
.Renviron
.env

# data stays in Unity Catalog, not in Git
data/
*.csv
*.parquet

# outputs are rebuilt by the pipeline
outputs/
_targets/` }] },
      { kind: 'h', text: 'A README a stranger can follow' },
      { kind: 'code', title: 'README.md', tabs: [{ lang: 'md', code:
`# Santa’s delivery statistics

Annual statistics on gifts delivered, by region.

## Run it
1. Clone this repository and open the project
2. Restore packages: renv::restore()  (Python: uv sync)
3. Set DATABRICKS_* environment variables (see Day 7)
4. Run the pipeline: targets::tar_make()  (Python: uv run python run_pipeline.py)

## Inputs
dash_catalog.santa.deliveries (Unity Catalog)

## Owner
[Team name] · [contact]` }] },
      { kind: 'links', items: [L.infra, L.cookie, L.qa] },
    ],
  },

  4: {
    intro: 'Copy-paste is the most common source of mistakes in analysis. Today’s challenge: turn repeated code into one function, and move the settings into a config file.',
    blocks: [
      { kind: 'h', text: 'Before: the copy-paste trap' },
      { kind: 'code', tabs: [
        { lang: 'r', code:
`north <- deliveries |> filter(region == "North", !is.na(child_id)) |> mutate(name = str_to_title(name))
south <- deliveries |> filter(region == "South", !is.na(child_id)) |> mutate(name = str_to_title(name))
east  <- deliveries |> filter(region == "East",  !is.na(child_id)) |> mutate(name = str_to_title(name))
# …copied for every region, and again for 2025, 2024…` },
        { lang: 'py', code:
`north = deliveries[(deliveries.region == "North") & deliveries.child_id.notna()].assign(name=lambda d: d.name.str.title())
south = deliveries[(deliveries.region == "South") & deliveries.child_id.notna()].assign(name=lambda d: d.name.str.title())
east  = deliveries[(deliveries.region == "East")  & deliveries.child_id.notna()].assign(name=lambda d: d.name.str.title())
# …copied for every region, and again for 2025, 2024…` },
      ] },
      { kind: 'h', text: 'After: one function, one config file' },
      { kind: 'code', title: 'config', tabs: [
        { lang: 'r', label: 'config.yml (R)', code:
`default:
  year: 2026
  source_table: dash_catalog.santa.deliveries
  regions: [North, South, East, West]
  output_dir: outputs` },
        { lang: 'py', label: 'config.yaml (Python)', code:
`year: 2026
source_table: dash_catalog.santa.deliveries
regions: [North, South, East, West]
output_dir: outputs` },
      ] },
      { kind: 'code', title: 'The function', tabs: [
        { lang: 'r', code:
`#' Clean one region's deliveries
#' @param data Deliveries data frame
#' @param region_name Region to keep
clean_region <- function(data, region_name) {
  data |>
    dplyr::filter(region == region_name, !is.na(child_id)) |>
    dplyr::mutate(name = stringr::str_to_title(name))
}

cfg <- config::get()                       # reads config.yml
cleaned <- purrr::map(cfg$regions, \\(r) clean_region(deliveries, r))` },
        { lang: 'py', code:
`from pathlib import Path
import pandas as pd
import yaml


def clean_region(data: pd.DataFrame, region: str) -> pd.DataFrame:
    """Clean one region's deliveries."""
    out = data[(data["region"] == region) & data["child_id"].notna()].copy()
    out["name"] = out["name"].str.title()
    return out


cfg = yaml.safe_load(Path("config.yaml").read_text())
cleaned = {r: clean_region(deliveries, r) for r in cfg["regions"]}` },
      ] },
      { kind: 'callout', tone: 'tip', title: 'What belongs in config?', text: 'Anything that changes between runs or environments: the reporting **year**, **table names** in Unity Catalog, **thresholds**, **output folders**. Secrets do **not** go in config – they go in environment variables (Day 7).' },
      { kind: 'h', text: 'Your challenge' },
      { kind: 'list', ordered: true, items: [
        'Find one block of code in your own work that’s been copied at least twice',
        'Turn it into a function with a clear name and a one-line description',
        'Move any hard-coded year, table or threshold into a config file',
        'Re-run and check you get exactly the same output as before',
      ] },
      { kind: 'reveal', label: 'Bonus: write summarise_region() – show a model answer', blocks: [
        { kind: 'code', tabs: [
          { lang: 'r', code:
`summarise_region <- function(data) {
  data |>
    dplyr::filter(!is_test_household) |>
    dplyr::count(region, name = "gifts")
}` },
          { lang: 'py', code:
`def summarise_region(data: pd.DataFrame) -> pd.DataFrame:
    """Count gifts by region, excluding test households."""
    return (
        data[~data["is_test_household"]]
        .groupby("region", as_index=False)
        .size()
        .rename(columns={"size": "gifts"})
    )` },
        ] },
        { kind: 'p', text: 'You’ll write tests for this exact function on Day 9.' },
      ] },
      { kind: 'links', items: [L.qa, L.tidyStyle, L.pep8] },
    ],
  },

  5: {
    intro: 'The elves dropped Santa’s report pipeline. Load the parcels onto the sleigh in the order they run – and watch out for manual steps that don’t belong.',
    blocks: [
      { kind: 'interactive', name: 'pipeline' },
      { kind: 'h', text: 'From game to real pipeline' },
      { kind: 'flow', title: 'Each stage is a function that takes the previous stage’s output', nodes: [
        { t: 'read_deliveries()', s: 'Unity Catalog', tag: 'Databricks', k: 'data' },
        { t: 'validate_deliveries()', s: 'stop on bad data', k: 'check' },
        { t: 'clean_deliveries()', s: 'tidy & standardise', k: 'code' },
        { t: 'summarise_region()', s: 'gifts per region', k: 'code' },
        { t: 'make_charts()', s: 'figures & tables', k: 'code' },
        { t: 'render_report()', s: 'Quarto → HTML', tag: 'Posit Connect', k: 'out' },
      ] },
      { kind: 'p', text: 'Pipeline tools work out this order for you from the dependencies, and only re-run the stages whose inputs have changed.' },
      { kind: 'code', title: 'Declaring the pipeline', tabs: [
        { lang: 'r', label: '_targets.R (R)', code:
`library(targets)
tar_source("R/")                                   # load your functions
tar_option_set(packages = c("dplyr", "ggplot2"))

list(
  tar_target(cfg,       config::get()),
  tar_target(raw,       read_deliveries(cfg)),     # from Unity Catalog
  tar_target(checked,   validate_deliveries(raw)),
  tar_target(clean,     clean_deliveries(checked)),
  tar_target(by_region, summarise_region(clean)),
  tar_target(charts,    make_charts(by_region)),
  tar_target(report,    render_report(by_region, charts), format = "file")
)

# run with targets::tar_make() – only out-of-date steps re-run
# see the dependency graph with targets::tar_visnetwork()` },
        { lang: 'py', label: 'run_pipeline.py (Python)', code:
`"""Run Santa's delivery statistics end to end."""
from santa_stats import stages


def main(config_path: str = "config.yaml") -> None:
    cfg = stages.load_config(config_path)
    raw = stages.read_deliveries(cfg)          # from Unity Catalog
    checked = stages.validate_deliveries(raw)
    clean = stages.clean_deliveries(checked)
    by_region = stages.summarise_region(clean)
    charts = stages.make_charts(by_region)
    stages.render_report(by_region, charts)


if __name__ == "__main__":
    main()

# For caching and dependency tracking, look at Snakemake or DVC.` },
      ] },
      { kind: 'callout', tone: 'defra', title: 'Running stages inside Databricks', text: 'For heavier data processing on DASH, **Lakeflow Jobs** (formerly Databricks Workflows) run notebooks or scripts as tasks in a dependency graph, on a schedule or a trigger. A common pattern: a Databricks job builds a clean summary table in Unity Catalog, then a Quarto report on Posit Connect reads from it.' },
      { kind: 'links', items: [L.targets, L.jobs, L.qa] },
    ],
  },

  6: {
    intro: 'Tick off what’s true of your project today. You’ll get your RAP level, your single next best step, and a checklist you can paste into a GitHub issue or QA log.',
    blocks: [
      { kind: 'interactive', name: 'checklist' },
      { kind: 'callout', tone: 'tip', title: 'Where the levels come from', text: 'Baseline, Silver and Gold are adapted from the NHS England **Levels of RAP** framework. Use them as a direction of travel, not a pass/fail test.' },
      { kind: 'links', items: [L.nhsLevels, L.rapMVP, L.qa] },
    ],
  },

  7: {
    intro: '“It works on my machine” is the most famous phrase in analysis. Today: keeping secrets out of code, connecting to Databricks on DASH from R and Python, and locking your package versions.',
    blocks: [
      { kind: 'h', text: '1. Keep secrets out of your code' },
      { kind: 'p', text: 'Your Databricks connection details live in **environment variables**, in a file that Git ignores. You’ll find the **Server hostname** and **HTTP path** on your SQL warehouse’s **Connection details** tab.' },
      { kind: 'code', title: 'Your personal secrets file – never commit it', tabs: [
        { lang: 'r', label: '.Renviron (R)', code:
`# open with usethis::edit_r_environ(), then restart R
DATABRICKS_HOST=https://adb-0000000000000000.0.azuredatabricks.net
DATABRICKS_HTTP_PATH=/sql/1.0/warehouses/0000000000000000
DATABRICKS_TOKEN=<your personal access token>` },
        { lang: 'py', label: '.env (Python)', code:
`# load with python-dotenv or your IDE
DATABRICKS_SERVER_HOSTNAME=adb-0000000000000000.0.azuredatabricks.net
DATABRICKS_HTTP_PATH=/sql/1.0/warehouses/0000000000000000
DATABRICKS_TOKEN=<your personal access token>` },
      ] },
      { kind: 'h', text: '2. Connect to Databricks (DASH)' },
      { kind: 'flow', title: 'How your code reaches the data', nodes: [
        { t: 'Your R / Python code', s: 'laptop or Workbench', k: 'code' },
        { t: 'Environment variables', s: 'host · path · token', k: 'check' },
        { t: 'SQL warehouse', s: 'Databricks compute', tag: 'DASH', k: 'platform' },
        { t: 'Unity Catalog table', s: 'catalog.schema.table', tag: 'DASH', k: 'data' },
        { t: 'Data frame', s: 'back in your session', k: 'out' },
      ] },
      { kind: 'code', title: 'Query a Unity Catalog table', tabs: [
        { lang: 'r', code:
`library(DBI)

# odbc::databricks() reads DATABRICKS_HOST and DATABRICKS_TOKEN for you
con <- dbConnect(
  odbc::databricks(),
  httpPath = Sys.getenv("DATABRICKS_HTTP_PATH")
)

gifts <- dbGetQuery(
  con,
  "SELECT region, COUNT(*) AS gifts
     FROM dash_catalog.santa.deliveries
    WHERE delivery_year = ?
    GROUP BY region",
  params = list(2026)          # parameters, never pasted strings
)

dbDisconnect(con)` },
        { lang: 'py', code:
`# pip install databricks-sql-connector   (or: uv add databricks-sql-connector)
import os
import pandas as pd
from databricks import sql

with sql.connect(
    server_hostname=os.getenv("DATABRICKS_SERVER_HOSTNAME"),
    http_path=os.getenv("DATABRICKS_HTTP_PATH"),
    access_token=os.getenv("DATABRICKS_TOKEN"),
) as conn, conn.cursor() as cur:
    cur.execute(
        "SELECT region, COUNT(*) AS gifts "
        "FROM dash_catalog.santa.deliveries "
        "WHERE delivery_year = :year GROUP BY region",
        {"year": 2026},       # named parameters, never f-strings
    )
    gifts = pd.DataFrame(cur.fetchall(), columns=[c[0] for c in cur.description])` },
        { lang: 'sql', label: 'In a Databricks notebook', code:
`-- Inside Databricks you're already connected: no host, path or token needed.
SELECT region, COUNT(*) AS gifts
FROM dash_catalog.santa.deliveries
WHERE delivery_year = 2026
GROUP BY region;

-- Python cell equivalent:
-- df = spark.read.table("dash_catalog.santa.deliveries")` },
      ] },
      { kind: 'callout', tone: 'defra', title: 'Use your own catalog names', text: 'Unity Catalog uses three-part names: `catalog.schema.table`. The names on this page are made up – copy the real ones from **Catalog Explorer** in your DASH workspace. If you can’t see a table, ask its data owner for access rather than taking a copy.' },
      { kind: 'callout', tone: 'tip', title: 'On Posit Connect', text: 'Set the same variables in your content’s **Vars** settings on Posit Connect – never in code. Where your Connect server supports it, viewer or service-principal credentials can replace personal tokens altogether.' },
      { kind: 'h', text: '3. Lock your package versions' },
      { kind: 'p', text: 'A lockfile records the exact version of every package, so next year’s run uses the same tools as this year’s. Commit the lockfile to Git.' },
      { kind: 'code', tabs: [
        { lang: 'r', code:
`renv::init()       # once per project: creates renv.lock
renv::snapshot()   # after installing or updating packages
renv::restore()    # a colleague (or CI, or Connect) gets identical versions` },
        { lang: 'py', code:
`# in a terminal
uv init                                  # once per project: pyproject.toml
uv add pandas databricks-sql-connector   # adds packages and writes uv.lock
uv sync                                  # a colleague gets identical versions
uv run python run_pipeline.py            # runs inside that environment` },
      ] },
      { kind: 'links', items: [L.odbc, L.positDbx, L.pyConn, L.renv, L.uv, L.connect] },
    ],
  },

  8: {
    intro: 'A pull request has landed in the workshop. Be the reviewer: find the five problems before it’s merged. Switch between R and Python at the top.',
    blocks: [
      { kind: 'interactive', name: 'review' },
      { kind: 'h', text: 'What good reviewers look for' },
      { kind: 'list', items: [
        '**Does it run?** Pull the branch and run it yourself – on your machine, not theirs',
        '**Is it right?** Do the numbers make sense against last year’s, or another source?',
        '**Can I follow it?** Names, comments, and a README that explains the why',
        '**Is anything hard-coded?** Paths, years, table names, secrets',
        '**Is it tested?** Are the important functions covered (Day 9)?',
      ] },
      { kind: 'h', text: 'Let the robots do the nit-picking' },
      { kind: 'p', text: 'Linters and formatters enforce a style guide automatically, so human reviewers can focus on logic.' },
      { kind: 'code', tabs: [
        { lang: 'r', code:
`lintr::lint_dir("R")     # flags style problems and likely bugs
styler::style_dir("R")   # rewrites code in tidyverse style` },
        { lang: 'py', code:
`# in a terminal
uv add --dev ruff
uv run ruff check .      # flags style problems and likely bugs
uv run ruff format .     # rewrites code in a consistent style` },
      ] },
      { kind: 'callout', tone: 'tip', title: 'Be kind, be specific', text: 'Comment on the code, not the person. Ask questions (“Could the year come from config?”) and say what’s good as well as what needs changing.' },
      { kind: 'links', items: [L.tidyStyle, L.pep8, L.lintr, L.ruff, L.qa] },
    ],
  },

  9: {
    intro: 'Unit tests are Santa’s list for your functions: written once, checked twice – and every time anything changes.',
    blocks: [
      { kind: 'h', text: 'A function worth testing' },
      { kind: 'code', tabs: [
        { lang: 'r', label: 'R/summarise_region.R', code:
`summarise_region <- function(data) {
  data |>
    dplyr::filter(!is_test_household) |>
    dplyr::count(region, name = "gifts")
}` },
        { lang: 'py', label: 'src/santa_stats/summarise.py', code:
`import pandas as pd


def summarise_region(data: pd.DataFrame) -> pd.DataFrame:
    """Count gifts by region, excluding test households."""
    return (
        data[~data["is_test_household"]]
        .groupby("region", as_index=False)
        .size()
        .rename(columns={"size": "gifts"})
    )` },
      ] },
      { kind: 'h', text: 'Its tests' },
      { kind: 'code', tabs: [
        { lang: 'r', label: 'tests/testthat/test-summarise_region.R', code:
`test_that("test households are excluded", {
  fake <- tibble::tibble(
    region = c("North", "North", "South"),
    is_test_household = c(FALSE, TRUE, FALSE)
  )
  result <- summarise_region(fake)
  expect_equal(result$gifts[result$region == "North"], 1)
})

test_that("every region appears exactly once", {
  fake <- tibble::tibble(region = c("North", "South", "South"),
                         is_test_household = FALSE)
  expect_false(anyDuplicated(summarise_region(fake)$region) > 0)
})

# run with: devtools::test()  or  testthat::test_dir("tests/testthat")` },
        { lang: 'py', label: 'tests/test_summarise.py', code:
`import pandas as pd
from santa_stats.summarise import summarise_region


def test_test_households_are_excluded():
    fake = pd.DataFrame({"region": ["North", "North", "South"],
                         "is_test_household": [False, True, False]})
    result = summarise_region(fake).set_index("region")
    assert result.loc["North", "gifts"] == 1


def test_every_region_appears_once():
    fake = pd.DataFrame({"region": ["North", "South", "South"],
                         "is_test_household": [False] * 3})
    assert summarise_region(fake)["region"].is_unique

# run with: uv run pytest` },
      ] },
      { kind: 'flow', title: 'Tests as a safety net', nodes: [
        { t: 'Change the code', s: 'new method or fix', k: 'code' },
        { t: 'Run the tests', s: 'seconds, not hours', k: 'check' },
        { t: 'All green?', s: 'if not, fix first', k: 'check' },
        { t: 'Open a pull request', s: 'reviewer sees results', k: 'out' },
      ] },
      { kind: 'callout', tone: 'tip', title: 'Use tiny fake data', text: 'Build test data in the test itself – three or four rows that show the rule. Tests then run anywhere in seconds, without a Databricks connection or real records.' },
      { kind: 'h', text: 'What’s worth testing?' },
      { kind: 'list', items: [
        'Business rules (“test households are excluded”)',
        'Edge cases: empty input, missing values, a region with no deliveries',
        'Anything that has gone wrong before – write the test when you fix the bug',
      ] },
      { kind: 'links', items: [L.testthat, L.pytest, L.qa] },
    ],
  },

  10: {
    intro: 'Bad data doesn’t announce itself. Today you’re the gatekeeper: spot the parcels that should stop the pipeline, then see how to catch them automatically.',
    blocks: [
      { kind: 'interactive', name: 'parcels' },
      { kind: 'flow', title: 'Fail early, fail loudly', nodes: [
        { t: 'New data arrives', s: 'Unity Catalog', tag: 'DASH', k: 'data' },
        { t: 'Validation checks', s: 'nulls · ranges · keys', k: 'check' },
        { t: 'Pass → continue', s: 'clean, summarise, report', k: 'code' },
        { t: 'Fail → stop & tell someone', s: 'no silent errors', k: 'manual' },
      ] },
      { kind: 'code', title: 'Turn your checks into code', tabs: [
        { lang: 'r', code:
`library(pointblank)

# each check stops the pipeline with an error if any row fails
deliveries |>
  col_vals_not_null(columns = c(child_id, region)) |>
  rows_distinct(columns = child_id) |>
  col_vals_in_set(columns = region,
                  set = c("North", "South", "East", "West")) |>
  col_vals_between(columns = gifts, left = 0, right = 10)` },
        { lang: 'py', code:
`import pandera.pandas as pa

schema = pa.DataFrameSchema({
    "child_id": pa.Column(str, nullable=False, unique=True),
    "region": pa.Column(str, pa.Check.isin(["North", "South", "East", "West"]),
                        nullable=False),
    "gifts": pa.Column(int, pa.Check.in_range(0, 10)),
})

schema.validate(deliveries)   # raises an error listing every failing row` },
        { lang: 'sql', label: 'At the source (Databricks)', code:
`-- Delta table constraints reject bad rows when they're written
ALTER TABLE dash_catalog.santa.deliveries
  ALTER COLUMN region SET NOT NULL;

ALTER TABLE dash_catalog.santa.deliveries
  ADD CONSTRAINT gifts_in_range CHECK (gifts BETWEEN 0 AND 10);` },
      ] },
      { kind: 'callout', tone: 'defra', title: 'Where should checks live?', text: 'If you own the table on DASH, **constraints** stop bad rows at the source. If you’re reading someone else’s table, validate it at the **start of your pipeline** – and tell the data owner what you found.' },
      { kind: 'links', items: [L.pointblank, L.pandera, L.constraints] },
    ],
  },

  11: {
    intro: 'Let the robots do the boring bits: run your tests on every change, deploy automatically, and refresh the outputs on a schedule.',
    blocks: [
      { kind: 'flow', title: 'From commit to published, hands-free', nodes: [
        { t: 'Push to Git', s: 'branch + pull request', k: 'code' },
        { t: 'CI runs tests', s: 'GitHub Actions / Azure DevOps', k: 'check' },
        { t: 'Review & merge', s: 'only green builds', k: 'check' },
        { t: 'Deploy', s: 'report, app or API', tag: 'Posit Connect', k: 'platform' },
        { t: 'Scheduled refresh', s: 'Connect schedule or Lakeflow Job', k: 'out' },
      ] },
      { kind: 'h', text: 'Continuous integration: tests on every push' },
      { kind: 'code', title: '.github/workflows/tests.yml', tabs: [
        { lang: 'r', code:
`name: tests
on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: r-lib/actions/setup-r@v2
      - uses: r-lib/actions/setup-renv@v2     # restores renv.lock
      - run: Rscript -e 'testthat::test_dir("tests/testthat")'` },
        { lang: 'py', code:
`name: tests
on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v6
      - run: uv sync                 # restores uv.lock
      - run: uv run ruff check .
      - run: uv run pytest` },
      ] },
      { kind: 'callout', tone: 'defra', title: 'Using Azure DevOps instead?', text: 'The steps are the same – restore the environment, lint, run the tests – they just live in `azure-pipelines.yml`. Keep secrets in your CI tool’s secret store, never in the YAML file.' },
      { kind: 'h', text: 'Deploy and schedule' },
      { kind: 'code', title: 'Publish to Posit Connect from code', tabs: [
        { lang: 'r', code:
`# publish the Quarto report *with source code* so Connect can re-run it
quarto::quarto_publish_doc(
  "report.qmd",
  name = "santa-delivery-stats",
  server = "<your Posit Connect server>"
)` },
        { lang: 'py', code:
`# in a terminal (pip install rsconnect-python)
rsconnect deploy quarto . \\
  --server <your Posit Connect server> \\
  --api-key $CONNECT_API_KEY` },
      ] },
      { kind: 'list', items: [
        '**Posit Connect schedules** re-render reports that were published with their source code – ideal for a weekly Quarto report',
        '**Lakeflow Jobs** in Databricks run heavier processing as a graph of tasks on a schedule – ideal for building the tables your report reads',
      ] },
      { kind: 'h', text: 'Gold level: package it' },
      { kind: 'code', tabs: [
        { lang: 'r', code:
`usethis::create_package("santastats")   # DESCRIPTION, R/, tests/
usethis::use_testthat()
usethis::use_news_md()                  # a changelog for every release` },
        { lang: 'py', code:
`# in a terminal
uv init --package santa-stats     # pyproject.toml + src/ layout
uv add --dev pytest ruff` },
      ] },
      { kind: 'links', items: [L.rlibActions, L.ghActions, L.connectSched, L.jobs] },
    ],
  },

  12: {
    intro: 'The final challenge: prove the whole pipeline is reproducible. Clone it, run one command, get exactly the published numbers. Then claim your badge.',
    blocks: [
      { kind: 'h', text: 'The reproducibility test' },
      { kind: 'list', ordered: true, items: [
        '**Clone** the repository onto a machine that has never run it',
        '**Restore** the exact package versions from the lockfile',
        '**Set** your own `DATABRICKS_*` environment variables (Day 7)',
        '**Run** the whole pipeline with one command',
        '**Compare** your output with the published one – they should match exactly',
      ] },
      { kind: 'code', tabs: [
        { lang: 'r', code:
`# 1. git clone <repository url>, then open the .Rproj
renv::restore()                      # 2. exact package versions
                                     # 3. secrets in your own .Renviron
targets::tar_make()                  # 4. run everything

# 5. same answer as published?
new <- read.csv("outputs/gifts_by_region.csv")
published <- read.csv("published/gifts_by_region.csv")
waldo::compare(new, published)       # "✔ No differences"` },
        { lang: 'py', code:
`# 1. git clone <repository url> && cd santa-stats
# 2. uv sync                         – exact versions from uv.lock
# 3. secrets in your own .env
# 4. uv run python run_pipeline.py   – run everything

# 5. same answer as published?
import pandas as pd

new = pd.read_csv("outputs/gifts_by_region.csv")
published = pd.read_csv("published/gifts_by_region.csv")
pd.testing.assert_frame_equal(new, published)   # silent = identical` },
      ] },
      { kind: 'callout', tone: 'tip', title: 'If it doesn’t match', text: 'That’s the point of the test. Look for an unrecorded package version, a missing seed, a manual step, or data that changed in the source table – then fix the pipeline, not the output.' },
      { kind: 'flow', title: 'Everything you’ve unwrapped', nodes: [
        { t: 'Git', s: 'Day 3', k: 'code' },
        { t: 'Functions & config', s: 'Day 4', k: 'code' },
        { t: 'Environments', s: 'Day 7', tag: 'DASH', k: 'platform' },
        { t: 'Validation', s: 'Day 10', k: 'check' },
        { t: 'Tests & review', s: 'Days 8–9', k: 'check' },
        { t: 'Automation', s: 'Day 11', tag: 'Posit Connect', k: 'out' },
      ] },
      { kind: 'h', text: 'Your badge and your pledge' },
      { kind: 'interactive', name: 'pledge' },
      { kind: 'links', items: [L.rapAF, L.rapMVP, L.nhsLevels] },
    ],
  },
};
