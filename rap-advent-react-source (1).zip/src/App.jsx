import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Sparkles from './Sparkles.jsx';
import Tree from './Tree.jsx';
import DayPage from './DayPage.jsx';
import { TREATS, LEVELS } from './treats.js';

const STORE_KEY = 'rap-advent-v1';
const load = () => {
  try { return JSON.parse(localStorage.getItem(STORE_KEY)) || null; } catch { return null; }
};
const save = (v) => {
  try { localStorage.setItem(STORE_KEY, JSON.stringify(v)); } catch { /* storage unavailable */ }
};

// Doors unlock on the viewer's calendar date: day 1 on 1 December, day 12 on 12 December.
const EVENT_YEAR = 2026;
// Set to false to lock each door until its date (day 1 on 1 December, and so on).
const UNLOCK_ALL = true;
const DAY_MS = 864e5;
const midnight = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate());
const decDate = (day) => new Date(EVENT_YEAR, 11, day);

// 0 = before 1 Dec (all locked), 1–12 = that day, 13 = after 12 Dec (all open).
const adventDay = (now = new Date()) => {
  if (UNLOCK_ALL) return 13;
  // Local development only (`npm run dev`): add ?day=6 to the URL to test a date.
  // This branch is stripped from the production build.
  if (import.meta.env.DEV) {
    const q = new URLSearchParams(window.location.search).get('day');
    if (q !== null) return Math.max(0, Math.min(13, Number(q)));
  }
  const diff = Math.round((midnight(now) - decDate(1)) / DAY_MS);
  return diff < 0 ? 0 : Math.min(diff + 1, 13);
};
const sleepsUntil = (day, now = new Date()) => Math.round((decDate(day) - midnight(now)) / DAY_MS);

// Each treat page lives at #day-1 … #day-12; anything else shows the tree.
const parseRoute = () => {
  const m = window.location.hash.match(/^#day-(\d{1,2})$/);
  const d = m ? Number(m[1]) : null;
  return d && d >= 1 && d <= 12 ? d : null;
};

const TYPE_ICON = {
  Read: 'M4 5h6a3 3 0 0 1 2 1 3 3 0 0 1 2-1h6v14h-6a2 2 0 0 0-2 1 2 2 0 0 0-2-1H4z M12 6v14',
  Play: 'M7 8h10a4 4 0 0 1 4 4v1a4 4 0 0 1-7 2.5h-4A4 4 0 0 1 3 13v-1a4 4 0 0 1 4-4z M8 10v4 M6 12h4 M16 11v.1 M17.5 13v.1',
  Tool: 'M14.5 6.5a4 4 0 0 0 5 5L12 19a2 2 0 0 1-3-3l7.5-7.5a4 4 0 0 0-2-2z',
  Challenge: 'M5 21V4 M5 4h12l-2 4 2 4H5',
};

function Icon({ d, size = 20, stroke = 'currentColor', width = 1.8 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true">
      <path d={d} fill="none" stroke={stroke} strokeWidth={width} strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function TreatIcon({ treat, size = 72 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" aria-hidden="true">
      <path d={treat.icon[0]} fill="none" stroke="#4F6B50" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
      <path d={treat.icon[1]} fill="none" stroke="#D2553F" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function TreatDialog({ treat, opened, onClose, onOpen }) {
  const panelRef = useRef(null);
  const lastFocus = useRef(null);

  useEffect(() => {
    lastFocus.current = document.activeElement;
    panelRef.current?.focus();
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('keydown', onKey);
      lastFocus.current?.focus?.();
    };
  }, [onClose]);

  return (
    <div className="overlay" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="dialog" role="dialog" aria-modal="true" aria-labelledby="dlg-title" tabIndex={-1} ref={panelRef}>
        <button type="button" className="close" onClick={onClose} aria-label="Close">
          <Icon d="M6 6l12 12M18 6L6 18" size={22} width={2.2} />
        </button>
        <div className="dialog__head">
          <TreatIcon treat={treat} />
          <div>
            <p className="eyebrow">
              Day {treat.day} · {treat.type} · {LEVELS.find((l) => l.id === treat.level).label} level · {treat.mins} min
            </p>
            <h2 id="dlg-title">{treat.title}</h2>
          </div>
        </div>
        <p className="dialog__blurb">{treat.blurb}</p>
        <h3>You’ll learn</h3>
        <ul className="learn">
          {treat.learn.map((l) => <li key={l}>{l}</li>)}
        </ul>
        <div className="dialog__actions">
          <button type="button" className="btn btn--primary" onClick={onOpen}>
            {opened ? 'Open again' : 'Unwrap this treat'}
            <Icon d="M5 12h14M13 6l6 6-6 6" size={18} width={2.2} />
          </button>
          <button type="button" className="btn btn--ghost" onClick={onClose}>Maybe later</button>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const stored = useMemo(load, []);
  const [today, setToday] = useState(adventDay);
  const [opened, setOpened] = useState(() => new Set(stored?.opened ?? []));
  const [selected, setSelected] = useState(null);
  const [toast, setToast] = useState('');
  const [shaking, setShaking] = useState(null);
  const [route, setRoute] = useState(parseRoute);
  const [lang, setLang] = useState(stored?.lang === 'py' ? 'py' : 'r');
  const burstRef = useRef(null);

  useEffect(() => save({ opened: [...opened], lang }), [opened, lang]);

  useEffect(() => {
    const onHash = () => { setRoute(parseRoute()); setSelected(null); };
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);

  // Visiting an unlocked treat page counts as unwrapping it.
  useEffect(() => {
    if (route && route <= today) setOpened((o) => (o.has(route) ? o : new Set(o).add(route)));
  }, [route, today]);

  // Re-check the date every minute so a door unlocks at midnight without a reload.
  useEffect(() => {
    const id = setInterval(() => setToday(adventDay()), 60_000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(''), 2600);
    return () => clearTimeout(t);
  }, [toast]);

  const status = useCallback(
    (day) => (day > today ? 'locked' : opened.has(day) ? 'opened' : day === today ? 'today' : 'ready'),
    [today, opened]
  );

  const pick = (t, e) => {
    if (status(t.day) === 'locked') {
      setShaking(t.day);
      setTimeout(() => setShaking(null), 500);
      const wait = sleepsUntil(t.day);
      setToast(`No peeking! Day ${t.day} opens on ${t.day} December – ${wait} more sleep${wait === 1 ? '' : 's'}.`);
      return;
    }
    const r = e.currentTarget.getBoundingClientRect();
    burstRef.current?.(r.left + r.width / 2, r.top + r.height / 2);
    setSelected(t);
  };

  const unwrap = () => {
    const day = selected.day;
    setOpened((o) => new Set(o).add(day));
    setSelected(null);
    window.location.hash = `day-${day}`;
  };

  const closeDialog = useCallback(() => setSelected(null), []);

  const count = TREATS.filter((t) => t.day <= today && opened.has(t.day)).length;
  const badge = count >= 12 ? 'Gold' : count >= 8 ? 'Silver' : count >= 4 ? 'Baseline' : null;
  const todays = TREATS.find((t) => t.day === Math.min(today, 12));

  if (route) {
    const treat = TREATS.find((t) => t.day === route);
    return (
      <div className="page page--day">
        <Sparkles burstRef={burstRef} />
        <DayPage treat={treat} lang={lang} setLang={setLang} count={count} locked={route > today} />
      </div>
    );
  }

  return (
    <div className="page">
      <Sparkles burstRef={burstRef} />

      <header className="top">
        <h1>RAP Advent</h1>
        <p className="sub">12 days of useful tips for building Reproducible Analytical Pipelines using Defra’s tech stack</p>
      </header>

      <main className="stage">
        <aside className="card card--progress" aria-label="Your progress">
          <h2 className="card__title">Your sleigh</h2>
          <p className="big"><strong>{count}</strong> of 12 treats unwrapped</p>
          <div className="stars" aria-hidden="true">
            {TREATS.map((t) => (
              <svg key={t.day} viewBox="0 0 24 24" width="22" height="22">
                <path
                  d="M12 2.5l2.8 6.2 6.7.6-5.1 4.5 1.5 6.6L12 17l-5.9 3.4 1.5-6.6-5.1-4.5 6.7-.6z"
                  fill={opened.has(t.day) && t.day <= today ? '#E2B05A' : 'none'}
                  stroke={opened.has(t.day) && t.day <= today ? '#E2B05A' : '#A39A8A'}
                  strokeWidth="1.5"
                  strokeLinejoin="round"
                />
              </svg>
            ))}
          </div>
          <p className="muted">
            {badge ? <>You’ve earned the <strong>{badge}</strong> badge.</> : 'Unwrap 4 treats to earn your Baseline badge.'}
          </p>
          <div className="themes">
            <h3 className="themes__title">
              RAP knowledge themes unlocked <span>{count} / 12</span>
            </h3>
            <ul className="themes__list">
              {TREATS.map((t) => {
                const got = opened.has(t.day) && t.day <= today;
                return (
                  <li key={t.day} className={got ? 'theme theme--on' : 'theme'}>
                    {got ? (
                      <svg width="18" height="18" viewBox="0 0 24 24" role="img" aria-label="Unlocked">
                        <path d="M12 2.5l2.8 6.2 6.7.6-5.1 4.5 1.5 6.6L12 17l-5.9 3.4 1.5-6.6-5.1-4.5 6.7-.6z" fill="#E2B05A" />
                      </svg>
                    ) : (
                      <svg width="18" height="18" viewBox="0 0 24 24" role="img" aria-label="Locked">
                        <path d="M7 11V8a5 5 0 0 1 10 0v3 M5 11h14v10H5z" fill="none" stroke="#8A8272" strokeWidth="1.8" strokeLinejoin="round" />
                      </svg>
                    )}
                    <span>{t.theme}</span>
                  </li>
                );
              })}
            </ul>
          </div>
        </aside>

        <Tree status={status} onPick={pick} shaking={shaking} />

        <aside className="card card--today" aria-label="Today's treat">
          {today === 0 ? (
            <>
              <h2 className="card__title">Coming soon</h2>
              <TreatIcon treat={TREATS[0]} size={64} />
              <p className="today-title">The first door opens on 1 December.</p>
              <p className="countdown"><strong>{sleepsUntil(1)}</strong> sleep{sleepsUntil(1) === 1 ? '' : 's'} to go</p>
            </>
          ) : today > 12 ? (
            <>
              <h2 className="card__title">{UNLOCK_ALL ? 'All doors open' : 'That’s a wrap!'}</h2>
              <p>{UNLOCK_ALL ? 'Every treat is unlocked. Pick any number on the tree to unwrap it.' : 'All 12 treats are open. Go back to any you missed.'}</p>
            </>
          ) : (
            <>
              <h2 className="card__title">Today’s treat</h2>
              <TreatIcon treat={todays} size={64} />
              <p className="eyebrow">Day {todays.day} · {todays.type} · {todays.mins} min</p>
              <p className="today-title">{todays.title}</p>
              <button
                type="button"
                className="btn btn--primary"
                onClick={(e) => pick(todays, e)}
              >
                Open day {todays.day}
              </button>
            </>
          )}
          <p className="muted small">Move your cursor around the tree…</p>
        </aside>
      </main>


      <div className={`toast${toast ? ' toast--on' : ''}`} role="status" aria-live="polite">{toast}</div>

      {selected && (
        <TreatDialog
          treat={selected}
          opened={opened.has(selected.day)}
          onClose={closeDialog}
          onOpen={unwrap}
        />
      )}
    </div>
  );
}
