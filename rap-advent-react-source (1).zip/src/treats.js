// The 12 treats. `x`/`y` place each number on the tree (tree viewBox 600 × 760):
// day 1 starts bottom-left and the days climb to 12 at the top.
// `icon` = [outline path, accent path] in a 48 × 48 box.
export const TREATS = [
  {
    day: 1, theme: 'Why RAP matters', type: 'Read', level: 'elf', mins: 4, x: 148, y: 600,
    title: 'Welcome to RAP: why pipelines?',
    blurb: 'What a Reproducible Analytical Pipeline is, and why it beats copy-paste-and-hope at publication time.',
    learn: ['What “reproducible” really means', 'The Baseline, Silver and Gold levels', 'Why open-source tools matter'],
    icon: ['M10 22h28v18H10z M8 16h32v6H8z M24 16v24', 'M24 16c-3-6-10-7-9-2s9 2 9 2c3-6 10-7 9-2s-9 2-9 2'],
  },
  {
    day: 2, theme: 'Reproducible habits', type: 'Play', level: 'elf', mins: 5, x: 300, y: 610,
    title: 'Naughty or Nice code?',
    blurb: 'Five snippets, R or Python. Decide which help reproducibility and which earn a lump of coal.',
    learn: ['Relative vs hard-coded paths', 'Random seeds', 'Config files and lockfiles'],
    icon: ['M24 4v6 M20 10h8v5h-8z M24 15a12 12 0 1 0 .1 0', 'M13 26h22 M13.5 31h21'],
  },
  {
    day: 3, theme: 'Version control', type: 'Read', level: 'elf', mins: 6, x: 452, y: 598,
    title: 'A Christmas Commit',
    blurb: 'The ghosts of Code Past, Present and Yet to Come show why version control and a good README save Christmas.',
    learn: ['git log, diff and commit', 'Writing useful commit messages', 'READMEs a stranger can follow'],
    icon: ['M8 30c4-1 6-7 4-11 4 2 10 0 12-4 0 6 4 9 8 9-4 2-6 8-4 12-4-2-9 0-12 4 0-6-4-9-8-10z', 'M23 23a2 2 0 1 0 .1 0 M28 21a2 2 0 1 0 .1 0 M26 27a2 2 0 1 0 .1 0'],
  },
  {
    day: 4, theme: 'Functions & config', type: 'Challenge', level: 'reindeer', mins: 15, x: 182, y: 498,
    title: 'Wrap it in a function',
    blurb: 'Turn a copy-pasted cleaning script into one tidy, reusable function driven by a config file.',
    learn: ['Spotting repetition', 'Writing small functions', 'Moving settings into config'],
    icon: ['M24 8a16 16 0 1 0 .1 0 M24 14a10 10 0 1 0 .1 0', 'M24 38l-4 6 M24 38l4 6 M24 38c-5-4-9 0-5 1s5-1 5-1c0 0 6-4 5-1s-5 1-5 1'],
  },
  {
    day: 5, theme: 'Pipeline design', type: 'Play', level: 'reindeer', mins: 5, x: 268, y: 478,
    title: 'Untangle the pipeline',
    blurb: 'Load the parcels onto the sleigh in the order the pipeline runs – but watch out for manual steps.',
    learn: ['Pipelines as connected stages', 'Why manual steps break reproducibility', '{targets}, Snakemake and DVC'],
    icon: ['M24 6l4.5 11 12 .5-9.5 7.5 3.5 11.5L24 30l-10.5 6.5 3.5-11.5L7.5 17.5l12-.5z', 'M24 30v11 M21 41h6'],
  },
  {
    day: 6, theme: 'Quality assurance', type: 'Tool', level: 'elf', mins: 5, x: 412, y: 505,
    title: 'RAP readiness checker',
    blurb: 'Tick off what your project does today and get your RAP level, your next best step and a QA record.',
    learn: ['Where your project sits', 'Your single next improvement', 'A QA record for sign-off'],
    icon: ['M16 42V22c0-8 4-14 10-14s8 6 8 12v22z M16 26c-4 0-6-4-4-8', 'M14 36h22 M14 39h22'],
  },
  {
    day: 7, theme: 'Environments & dependencies', type: 'Read', level: 'reindeer', mins: 7, x: 222, y: 372,
    title: 'Sleigh-ready environments',
    blurb: 'Why your code works on your laptop but not on the server – and how lockfiles fix it.',
    learn: ['renv, requirements.txt and uv', 'Relative paths and projects', 'Running on Posit Connect'],
    icon: ['M14 34c2-2 2-6 2-12a8 8 0 0 1 16 0c0 6 0 10 2 12z M24 6v4', 'M22 38a2 2 0 0 0 4 0 M24 10c-3-4-9-3-7 0s7 0 7 0c3-4 9-3 7 0s-7 0-7 0'],
  },
  {
    day: 8, theme: 'Peer review & style', type: 'Play', level: 'reindeer', mins: 10, x: 305, y: 352,
    title: 'Code review elf: spot 5 issues',
    blurb: 'A pull request has landed in the workshop. Find the five problems before it’s merged.',
    learn: ['What reviewers look for', 'Style guides and linters', 'Giving kind, useful feedback'],
    icon: ['M17 14h14v22H17z M15 36h18 M20 14l4-6 4 6', 'M24 20c-2.5 2.5-2.5 7 0 10 2.5-3 2.5-7.5 0-10z'],
  },
  {
    day: 9, theme: 'Testing', type: 'Read', level: 'reindeer', mins: 8, x: 388, y: 385,
    title: 'Checking it twice',
    blurb: 'Unit tests are Santa’s list for your functions: written once, checked every time anything changes.',
    learn: ['testthat and pytest basics', 'What’s worth testing', 'Tests as documentation'],
    icon: ['M18 14h12v13l6 8a6 6 0 0 1-8 7l-11-11z', 'M17 8h14v6H17z'],
  },
  {
    day: 10, theme: 'Data validation', type: 'Play', level: 'reindeer', mins: 10, x: 262, y: 245,
    title: 'Catch the bad parcels',
    blurb: 'Parcels are flying down the chimney – catch the ones with bad data before they reach the report.',
    learn: ['Validating inputs automatically', 'pointblank and pandera', 'Failing loudly and early'],
    icon: ['M24 6v10 M24 16c-8 0-12 6-12 12 M24 16c8 0 12 6 12 12 M18 20c-4-2-8 0-9 3 M30 20c4-2 8 0 9 3', 'M12 31a2 2 0 1 0 .1 0 M36 31a2 2 0 1 0 .1 0 M24 21a2 2 0 1 0 .1 0'],
  },
  {
    day: 11, theme: 'Automation & CI', type: 'Read', level: 'santa', mins: 8, x: 345, y: 262,
    title: 'Automate the sleigh',
    blurb: 'Let the robots run your tests on every change, and schedule the pipeline so it runs itself.',
    learn: ['GitHub Actions basics', 'Scheduling on Posit Connect', 'Packaging your code'],
    icon: ['M6 32h30c4 0 6-4 6-8 M10 32c-4 0-4-10 2-10h20v10 M6 38h32c2 0 4-2 4-4', 'M16 22v-7h12v7 M22 15v7'],
  },
  {
    day: 12, theme: 'End-to-end reproducibility', type: 'Challenge', level: 'elf', mins: 30, x: 300, y: 150,
    title: 'Reproduce Santa’s report',
    blurb: 'Clone the repo, run one command, get the same figure. Then claim your RAP badge and make a pledge.',
    learn: ['End-to-end reproducibility', 'Your RAP badge', 'One change for the new year'],
    icon: ['M6 42V24L24 10l18 14v18z M20 42V32h8v10', 'M31 17v-7h4v10 M11 28h5v5h-5z M32 28h5v5h-5z'],
  },
];

export const LEVELS = [
  { id: 'elf', label: 'Elf', desc: 'new to RAP' },
  { id: 'reindeer', label: 'Reindeer', desc: 'I code a bit' },
  { id: 'santa', label: 'Santa', desc: 'pipeline pro' },
];

export const RANK = { elf: 0, reindeer: 1, santa: 2 };
