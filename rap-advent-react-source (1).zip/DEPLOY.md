# Deploying the RAP Advent Calendar to Posit Connect

The calendar is a single, self-contained `index.html`: the JavaScript, CSS and fonts are all inside it.
It makes no calls to the internet, so it works on locked-down networks.

## What's in the bundle

```
rap-advent-connect-bundle.tar.gz
├── index.html      # the whole app
└── manifest.json   # tells Connect this is static content, with index.html as the main page
```

## Option 1 – Upload the bundle (no code)

1. Open Posit Connect and choose to publish or upload a new content bundle
   (the menu wording depends on your Connect version and how your admins have set it up).
2. Select `rap-advent-connect-bundle.tar.gz`.
3. When it has deployed, open the content's **Settings** to set the title, who can view it, and a vanity URL.

## Option 2 – Publish from R

```r
# install.packages("rsconnect")
rsconnect::deployApp(
  appDir = "connect-bundle",
  appPrimaryDoc = "index.html",
  appMode = "static",
  appTitle = "RAP Advent Calendar",
  server = "<your Posit Connect server>"
)
```

## Option 3 – Publish from Python

```bash
# pip install rsconnect-python
rsconnect deploy html connect-bundle/index.html \
  --title "RAP Advent Calendar" \
  --server <your Posit Connect server> \
  --api-key $CONNECT_API_KEY
```

## Rebuilding after changes

```bash
npm install          # first time only
npm run bundle       # builds dist/, connect-bundle/ and rap-advent-connect-bundle.tar.gz
```

Then re-upload, or redeploy to the same content item.

## Before launch

- Doors are currently **all unlocked** for review. To lock each door until its date,
  set `UNLOCK_ALL = false` in `src/App.jsx` and run `npm run bundle` again.
- Progress (opened doors, pledge, R/Python choice) is saved in each viewer's own browser.
  Nothing is sent back to Connect.
- Page text, code snippets and links are in `src/content.js`.
