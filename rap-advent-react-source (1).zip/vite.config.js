import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { viteSingleFile } from 'vite-plugin-singlefile';

// Builds to one self-contained dist/index.html – easy to publish as static
// content on Posit Connect.
export default defineConfig({
  plugins: [react(), viteSingleFile()],
  base: './',
});
