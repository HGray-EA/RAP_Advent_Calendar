// Builds a Posit Connect static-content bundle from dist/index.html:
//   connect-bundle/manifest.json
//   connect-bundle/index.html
//   rap-advent-connect-bundle.tar.gz   (index.html + manifest.json at the top level)
import { createHash } from 'node:crypto';
import { copyFileSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';

const out = 'connect-bundle';
rmSync(out, { recursive: true, force: true });
mkdirSync(out);

copyFileSync('dist/index.html', `${out}/index.html`);
const md5 = createHash('md5').update(readFileSync(`${out}/index.html`)).digest('hex');

const manifest = {
  version: 1,
  locale: 'en_GB.UTF-8',
  metadata: { appmode: 'static', primary_html: 'index.html' },
  files: { 'index.html': { checksum: md5 } },
};
writeFileSync(`${out}/manifest.json`, JSON.stringify(manifest, null, 2) + '\n');

execFileSync('tar', ['-czf', 'rap-advent-connect-bundle.tar.gz', '-C', out, 'index.html', 'manifest.json'], { stdio: 'inherit' });
console.log('Created rap-advent-connect-bundle.tar.gz and connect-bundle/ (index.html + manifest.json)');
